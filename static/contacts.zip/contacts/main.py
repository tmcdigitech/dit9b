import sqlite3
from bottle import route, run, debug, template, request, static_file, error, redirect, abort

# only needed when you run Bottle on mod_wsgi
# from bottle import default_app

@route('/')
def contact_list():
    output = template('tpl/home.html')
    return output



debug(True)
run(reloader=True)